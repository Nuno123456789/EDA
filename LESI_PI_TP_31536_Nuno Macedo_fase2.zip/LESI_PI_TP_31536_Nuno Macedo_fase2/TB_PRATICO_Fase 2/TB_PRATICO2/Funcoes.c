/*****************************************************************//**
 * \file   Funcoes.c
 * \brief  
 * 
 * \author Nuno Macedo
 * \date   May 2025
 *********************************************************************/
#include "funcoes.h"


#pragma region criarGrafo
Grafo* criarGrafo() {
    Grafo* grafo = (Grafo*)malloc(sizeof(Grafo));  // aloca mem�ria para o grafo
    if (grafo == NULL) return NULL;     
    // inicializa o n�mero de v�rtices e o vertice a zero
    grafo->numVertices = 0;      
    grafo->vertices = NULL;      
    return grafo;                // retorna o grafo criado
}

#pragma endregion



#pragma region adicionarVertice
int adicionarVertice(Grafo* grafo, char frequencia, int x, int y) {
    Vertice* novoVertices = (Vertice*)malloc((grafo->numVertices + 1) * sizeof(Vertice));  // aloca mem�ria para mais um v�rtice
    if (novoVertices == NULL) {
        return 0;  // falha na aloca��o
    }
    for (int i = 0; i < grafo->numVertices; i++) {
        novoVertices[i] = grafo->vertices[i];  // copia os v�rtices existentes
    }

    free(grafo->vertices);   // liberta a mem�ria antiga
    grafo->vertices = novoVertices;  // atualiza o apontador para os v�rtices

    grafo->vertices[grafo->numVertices].frequencia = frequencia;  // define a frequ�ncia
    grafo->vertices[grafo->numVertices].x = x;  // define coordenada X
    grafo->vertices[grafo->numVertices].y = y;  // define coordenada Y
    grafo->vertices[grafo->numVertices].adj = NULL;  // inicializa lista de adjac�ncia
    grafo->vertices[grafo->numVertices].visitado = false;  // marca como n�o visitado

    grafo->numVertices++;   // incrementa o n�mero de v�rtices
    return 1;  // sucesso
}
#pragma endregion



#pragma region adicionarAresta
int adicionarAresta(Grafo* grafo, int orig, int dest) {
    Aresta* novaAresta = (Aresta*)malloc(sizeof(Aresta));    // aloca mem�ria para a nova aresta 
    if (novaAresta == NULL) {
        return 0;    // falha na aloca��o
    }

    novaAresta->destino = dest;     // define o destino da aresta
    novaAresta->prox = grafo->vertices[orig].adj;    // aponta para a lista atual de adjac�ncia
    grafo->vertices[orig].adj = novaAresta;    // insere a nova aresta na lista do v�rtice de origem

    novaAresta = (Aresta*)malloc(sizeof(Aresta));  // aloca nova aresta para a liga��o inversa 
    if (novaAresta == NULL) {
        return 0;                                                
    }

    novaAresta->destino = orig;      // define o destino como o v�rtice de origem
    novaAresta->prox = grafo->vertices[dest].adj;   // aponta para a lista atual de adjac�ncia
    grafo->vertices[dest].adj = novaAresta;    // insere na lista do v�rtice de destino

    return 1;   // sucesso
}
#pragma endregion



#pragma region carregarFicheiro
Grafo* carregarFicheiro(const char* nomeFicheiro) {
    FILE* ficheiro = fopen(nomeFicheiro, "r");  // abre o ficheiro para leitura
    if (!ficheiro) {
        return NULL;     // retorna NULL se n�o conseguir abrir o ficheiro
    }

    Grafo* grafo = criarGrafo();  // cria grafo vazio
    char linha[100];   // buffer para cada linha do ficheiro
    int y = 0;  // coordenada Y atual

    while (fgets(linha, sizeof(linha), ficheiro)) {  // l� cada linha do ficheiro
        for (int x = 0; linha[x] != '\0'; x++) {   // percorre cada car�cter da linha
            char c = linha[x];
            if (c != '.' && c != '\n') {   // ignora pontos e novas linhas
                adicionarVertice(grafo, c, x, y);  // adiciona v�rtice com frequ�ncia e posi��o
            }
        }
        y++;     // incrementa a coordenada Y
    }

    fclose(ficheiro);  // fecha o ficheiro

    // conecta v�rtices com a mesma frequ�ncia
    for (int i = 0; i < grafo->numVertices; i++) {
        for (int j = i + 1; j < grafo->numVertices; j++) {
            if (grafo->vertices[i].frequencia == grafo->vertices[j].frequencia) {
                adicionarAresta(grafo, i, j);   // cria aresta entre v�rtices com a mesma frequ�ncia
            }
        }
    }

    return grafo;  // retorna o grafo carregado
}
#pragma endregion




#pragma region DFT

// Fun��es Pilha
void push(int stack[], int* top, int vertex) {
    stack[++(*top)] = vertex;  // incrementa o topo e adiciona o v�rtice
}


int pop(int stack[], int* top) {
    return stack[(*top)--];  // retorna o valor do topo e decrementa
}

bool isEmpty(int top) {
    return top == -1;  // pilha vazia se o topo for -1
}


int DFT(Grafo* grafo, int inicio, int visitados[]) {
    int stack[MAX];    // pilha para guardar os v�rtices a visitar
    int top = -1;   // topo da pilha
    int count = 0;  // contador de v�rtices visitados

    limparVisitados(grafo);     // marca todos os v�rtices como n�o visitados
    grafo->vertices[inicio].visitado = true;  // marca o v�rtice inicial como visitado
    push(stack, &top, inicio); // empilha o v�rtice inicial

    while (!isEmpty(top)) {     // enquanto houver v�rtices na pilha
        int v = pop(stack, &top);   // retira o v�rtice do topo
        visitados[count++] = v;    // guarda o v�rtice visitado

        Aresta* adj = grafo->vertices[v].adj;  // percorre a lista de adjac�ncia
        while (adj != NULL) {
            int destino = adj->destino;
            if (!grafo->vertices[destino].visitado) {
                grafo->vertices[destino].visitado = true;  // marca como visitado
                push(stack, &top, destino);    // empilha o v�rtice adjacente
            }
            adj = adj->prox;  // pr�ximo na lista
        }
    }

    return count;  // retorna quantos v�rtices foram visitados
}

#pragma endregion




#pragma region BFT
void enqueue(int queue[], int* rear, int vertex) {
    queue[(*rear)++] = vertex; // adiciona o v�rtice e incrementa o rear
}

int dequeue(int queue[], int* front) {
    return queue[(*front)++]; // retorna o v�rtice e incrementa o front
}

bool isQueueEmpty(int front, int rear) {
    return front == rear;   // fila vazia se front == rear
}

int BFT(Grafo* grafo, int inicio, int visitados[]) {
    int queue[MAX];  // array que representa a fila
    int front = 0, rear = 0;  // �ndices da frente e fim da fila
    int count = 0;  // n�mero de v�rtices visitados

    limparVisitados(grafo);   // marca todos como n�o visitados
    grafo->vertices[inicio].visitado = true; // marca o v�rtice inicial como visitado
    enqueue(queue, &rear, inicio);   // insere o v�rtice inicial na fila

    while (!isQueueEmpty(front, rear)) {  // enquanto a fila n�o estiver vazia
        int v = dequeue(queue, &front);  // retira o v�rtice da frente
        visitados[count++] = v;   // guarda o v�rtice visitado

        Aresta* adj = grafo->vertices[v].adj; // percorre a lista de adjac�ncia
        while (adj != NULL) {
            int destino = adj->destino;
            if (!grafo->vertices[destino].visitado) {
                grafo->vertices[destino].visitado = true; // marca como visitado
                enqueue(queue, &rear, destino);   // insere na fila
            }
            adj = adj->prox; // pr�ximo adjacente
        }
    }

    return count; // retorna quantos v�rtices foram visitados
}

#pragma endregion



#pragma region encontrarCaminhos

int encontrarCaminhos(Grafo* g, int atual, int destino, int* caminho, int pos) {
    int encontrou = 0;  // Vari�vel para indicar se encontrou algum caminho

    g->vertices[atual].visitado = true;  // Marca o v�rtice atual como visitado
    caminho[pos] = atual;  // Guarda o v�rtice atual na posi��o 'pos' do caminho

    if (atual == destino) {  // Se chegou ao destino
        for (int i = 0; i <= pos; i++) {  // Imprime o caminho encontrado
            printf("(%d, %d)", g->vertices[caminho[i]].x, g->vertices[caminho[i]].y);  // Imprime coordenadas do v�rtice
            if (i < pos) printf(" -> ");  // Se n�o � o �ltimo v�rtice, imprime seta
            else printf("\n");  // Sen�o, acaba a linha
        }
        encontrou = 1;  // Marca que encontrou pelo menos um caminho
    }
    else {
        Aresta* adj = g->vertices[atual].adj;  // Aponta para a lista de adjacentes do v�rtice atual
        while (adj != NULL) {  // Percorre todas as adjac�ncias
            int dest = adj->destino;  // �ndice do v�rtice adjacente

            if (!g->vertices[dest].visitado) {  // Se o v�rtice adjacente ainda n�o foi visitado
                if (encontrarCaminhos(g, dest, destino, caminho, pos + 1)) {  // Chamada recursiva para continuar o caminho
                    encontrou = 1;  // Se encontrou algum caminho na recurs�o, atualiza a vari�vel
                }
            }

            adj = adj->prox;  // Passa para a pr�xima aresta adjacente
        }
    }

    g->vertices[atual].visitado = false;  // Desmarca o v�rtice para permitir outros caminhos
    return encontrou;  // Retorna 1 se encontrou pelo menos um caminho, 0 caso contr�rio
}

#pragma endregion



#pragma region listarIntersecoes
int listarIntersecoes(Grafo* g, int v1, int v2) {
    Vertice a = g->vertices[v1]; 
    Vertice b = g->vertices[v2]; 

    int total = 0; // Inicializa o total

    printf("Vertices alinhados com (%d,%d) e (%d,%d):\n", a.x, a.y, b.x, b.y);

    for (int i = 0; i < g->numVertices; i++) { // Percorre todos os v�rtices do grafo
        if (i == v1 || i == v2) continue; // Ignora os v�rtices recebidos 

        Vertice atual = g->vertices[i]; // Obt�m o v�rtice atual para verifica��o

        if ((atual.x == a.x && atual.x == b.x) || // alinhamento vertical
            (atual.y == a.y && atual.y == b.y) || // alinhamento horizontal
            (abs(atual.x - a.x) == abs(atual.y - a.y) && // mesma diagonal entre a e atual
                abs(atual.x - b.x) == abs(atual.y - b.y))) { // mesma diagonal entre b e atual

            // Mostra o v�rtice alinhado encontrado
            printf("- %c (%d, %d)\n", atual.frequencia, atual.x, atual.y);
            total++; // Incrementa o total de interse��es encontradas
        }
    }

    return total; // Retorna o n�mero total de interse��es
}

#pragma endregion



#pragma region limparVisitados

int limparVisitados(Grafo* g) {
    if (g == NULL) return 0;  // Verifica se o grafo � n�o nulo

    for (int i = 0; i < g->numVertices; i++)  // Percorre todos os v�rtices do grafo
        g->vertices[i].visitado = false;      // Marca o v�rtice como n�o visitado

    return 1;   // Indica sucesso na limpeza
}
#pragma endregion




#pragma region limparGrafo
int limparGrafo(Grafo* grafo) {
    if (grafo == NULL) {
        return 0; // Nada para libertar
    }

    for (int i = 0; i < grafo->numVertices; i++) {
        Aresta* adj = grafo->vertices[i].adj;  // Aponta para a lista de adjac�ncia
        while (adj != NULL) {
            Aresta* temp = adj; // Guarda o n� atual para libertar
            adj = adj->prox; // Passa para o pr�ximo n�
            free(temp);  // Liberta o n� atual
        }
    }

    free(grafo->vertices);  // Liberta o array de v�rtices
    free(grafo);   // Liberta a estrutura do grafo

    return 1; // Libera��o bem-sucedida
}
#pragma endregion




#pragma region SalvarGrafoBinario
int guardarGrafoBinario(Grafo* grafo, const char* nomeArquivo) {
    FILE* fp = fopen(nomeArquivo, "wb");// Abre o ficheiro para escrita bin�ria
    if (!fp) {
        return 0;      // Falha ao abrir o ficheiro
    }
    // Escreve o n�mero de v�rtices
    if (fwrite(&grafo->numVertices, sizeof(int), 1, fp) != 1) {
        fclose(fp);
        return 0;
    }
    // Escreve os dados de cada v�rtice: frequ�ncia, x e y
    for (int i = 0; i < grafo->numVertices; i++) {
        Vertice* v = &grafo->vertices[i];
        if (fwrite(&v->frequencia, sizeof(char), 1, fp) != 1 ||
            fwrite(&v->x, sizeof(int), 1, fp) != 1 ||
            fwrite(&v->y, sizeof(int), 1, fp) != 1) {
            fclose(fp);
            return 0;
        }
    }
    // Para cada v�rtice, conta e escreve o n�mero de arestas 
    for (int i = 0; i < grafo->numVertices; i++) {
        Vertice* v = &grafo->vertices[i];
        int contArestas = 0;
        Aresta* adj = v->adj;
        while (adj != NULL) {
            contArestas++;  // Conta as arestas
            adj = adj->prox;
        }
        // Escreve o n�mero de arestas desse v�rtice
        if (fwrite(&contArestas, sizeof(int), 1, fp) != 1) {
            fclose(fp);
            return 0;
        }
        // Escreve o destino de cada aresta
        adj = v->adj;
        while (adj != NULL) {
            if (fwrite(&adj->destino, sizeof(int), 1, fp) != 1) {
                fclose(fp);
                return 0;
            }
            adj = adj->prox;
        }
    }
    fclose(fp);    // Fecha o ficheiro
    return 1;  // Sucesso
}
#pragma endregion




#pragma region carregarGrafoBinario
Grafo* carregarGrafoBinario(const char* nomeFicheiro) {
    FILE* f = fopen(nomeFicheiro, "rb");    // Abre o ficheiro para leitura bin�ria
    if (!f) {
        printf("Erro ao abrir arquivo %s\n", nomeFicheiro);
        return NULL;   // Falha ao abrir o ficheiro
    }
    Grafo* g = malloc(sizeof(Grafo));  // Aloca mem�ria para o grafo
    if (!g) {
        fclose(f);
        return NULL;   // Falha na aloca��o
    }
    // L� o n�mero de v�rtices
    if (fread(&g->numVertices, sizeof(int), 1, f) != 1) {
        printf("Erro ao ler numero de vertices\n");
        fclose(f);
        free(g);
        return NULL;   // Falha na leitura
    }
    // Aloca mem�ria para o array de v�rtices
    g->vertices = malloc(sizeof(Vertice) * g->numVertices);
    if (!g->vertices) {
        fclose(f);
        free(g);
        return NULL;  // Falha na aloca��o
    }
    // L� os dados de cada v�rtice e inicializa os campos adj e visitado
    for (int i = 0; i < g->numVertices; i++) {
        fread(&g->vertices[i].frequencia, sizeof(char), 1, f);
        fread(&g->vertices[i].x, sizeof(int), 1, f);
        fread(&g->vertices[i].y, sizeof(int), 1, f);
        g->vertices[i].adj = NULL;
        g->vertices[i].visitado = false;
    }
    // L� as arestas para cada v�rtice e constr�i as listas ligadas
    for (int i = 0; i < g->numVertices; i++) {
        int nArestas;
        fread(&nArestas, sizeof(int), 1, f);

        Aresta* ultimo = NULL;
        for (int j = 0; j < nArestas; j++) {
            int dest;
            fread(&dest, sizeof(int), 1, f);
            Aresta* a = malloc(sizeof(Aresta));
            a->destino = dest;
            a->prox = NULL;
            if (!g->vertices[i].adj) {   // Se � a primeira aresta
                g->vertices[i].adj = a;
            }
            else {
                ultimo->prox = a;    // Liga � �ltima aresta da lista
            }
            ultimo = a;
        }
    }
    fclose(f);   // Fecha o ficheiro
    return g;    // Retorna o grafo carregado
}
#pragma endregion













