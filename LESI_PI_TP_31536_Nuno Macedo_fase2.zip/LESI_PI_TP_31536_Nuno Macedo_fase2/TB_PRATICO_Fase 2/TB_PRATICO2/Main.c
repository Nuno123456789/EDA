/*****************************************************************//**
 * \file   Main.c
 * \brief  
 * 
 * \author Nuno Macedo
 * \date   May 2025
 *********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "funcoes.h"

void executarTudo(Grafo* grafo) {
    if (!grafo) {
        printf("Nao ha grafo carregado. Carregue um grafo primeiro.\n");
        return;
    }

    printf("Grafo carregado com sucesso!\n");
    printf("Numero de vertices: %d\n", grafo->numVertices);

    for (int i = 0; i < grafo->numVertices; i++) {
        printf("Antena %d: (%c, %d, %d)\n", i, grafo->vertices[i].frequencia, grafo->vertices[i].x, grafo->vertices[i].y);

        Aresta* adj = grafo->vertices[i].adj;
        while (adj != NULL) {
            printf(" -> Antena %d: (%c, %d, %d)\n", adj->destino, grafo->vertices[adj->destino].frequencia, grafo->vertices[adj->destino].x, grafo->vertices[adj->destino].y);
            adj = adj->prox;
        }
    }

    printf("\n=== DFT (Profundidade) ===\n");
    int visitados[MAX];
    int totalVisitados = DFT(grafo, 0, visitados);

    for (int i = 0; i < totalVisitados; i++) {
        int v = visitados[i];
        printf("Visitando (%d, %d) [%c]\n", grafo->vertices[v].x, grafo->vertices[v].y, grafo->vertices[v].frequencia);
    }

    printf("\n=== BFT (Largura) ===\n");
    int visitadosBFS[MAX];
    int totalVisitadosBFS = BFT(grafo, 0, visitadosBFS);

    for (int i = 0; i < totalVisitadosBFS; i++) {
        int v = visitadosBFS[i];
        printf("Visitando (%d, %d) [%c]\n", grafo->vertices[v].x, grafo->vertices[v].y, grafo->vertices[v].frequencia);
    }

    printf("\n=== Encontrar Caminhos ===\n");
    int caminho[MAX];
    limparVisitados(grafo);
    int encontrou = encontrarCaminhos(grafo, 1, 4, caminho, 0);
    if (!encontrou) {
        printf("Nenhum caminho encontrado.\n");
    }


    printf("\n=== Intersecoes ===\n");
    listarIntersecoes(grafo, 0, 9);

    printf("\n=== Fim da execucao ===\n");
}

int main() {
    Grafo* grafo = NULL;
    int opcao;

    do {
        printf("\n=== Menu Grafo ===\n");
        printf("1 - Carregar grafo de mapa.txt\n");
        printf("2 - Guardar grafo em binario\n");
        printf("3 - Carregar grafo de binario\n");
        printf("4 - Executar todas as funcoes com grafo carregado\n");
        printf("0 - Sair\n");
        printf("Escolha uma opcao: ");
        scanf_s("%d", &opcao);

        switch (opcao) {
        case 1:
            if (grafo) limparGrafo(grafo);
            grafo = carregarFicheiro("mapa.txt");
            if (grafo)
                printf("Grafo carregado com sucesso de mapa.txt!\n");
            else
                printf("Erro a carregar mapa.txt\n");
            break;
        case 2:
            if (!grafo) {
                printf("Primeiro carregue um grafo!\n");
            }
            else {
                guardarGrafoBinario(grafo, "grafo.bin");
                printf("Grafo guardado em grafo.bin\n");
            }
            break;
        case 3:
            if (grafo) 
                limparGrafo(grafo);
            grafo = carregarGrafoBinario("grafo.bin");
            if (grafo)
                printf("Grafo carregado com sucesso de grafo.bin!\n");
            else
                printf("Erro a carregar grafo.bin\n");
            break;
        case 4:
            executarTudo(grafo);
            break;
        case 0:
            printf("A sair...\n");
            break;
        default:
            printf("Opcao invalida!\n");
        }

    } while (opcao != 0);

    if (grafo) limparGrafo(grafo);
    return 0;
}
