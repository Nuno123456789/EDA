/*****************************************************************//**
 * \file   Funcoes.h
 * \brief  
 * 
 * 
 * \author Nuno Macedo
 * \date   May 2025
 *********************************************************************/
#ifndef FUNCOES_H
#define FUNCOES_H

#include "Dados.h"

Grafo* criarGrafo();/**
  * @brief Cria um grafo vazio.
  *
  * Aloca mem�ria para um grafo, inicializa o n�mero de v�rtices a zero
  * e o apontador para os v�rtices a NULL, indicando que est� vazio.
  *
  * @return Apontador para o grafo criado.
  */

int adicionarVertice(Grafo* grafo, char frequencia, int x, int y);/**
 * @brief Adiciona um novo v�rtice ao grafo.
 * 
 * Aloca espa�o para um novo v�rtice, copia os v�rtices existentes para uma nova �rea de mem�ria,
 * insere o novo v�rtice com os dados fornecidos e atualiza o n�mero de v�rtices do grafo.
 * 
 * @param grafo Apontador para o grafo onde o v�rtice ser� adicionado.
 * @param frequencia Car�cter que representa a frequ�ncia do v�rtice.
 * @param x Coordenada X do v�rtice.
 * @param y Coordenada Y do v�rtice.
 * @return int Retorna 1 em caso de sucesso e 0 se houver falha na aloca��o de mem�ria.
 */


int adicionarAresta(Grafo* grafo, int src, int dest);/**
 * @brief Adiciona uma aresta bidirecional entre dois v�rtices do grafo.
 * 
 * Esta fun��o cria duas arestas (uma em cada dire��o), ligando os v�rtices
 * de origem e destino.
 * 
 * @param grafo Apontador para o grafo onde a aresta ser� adicionada.
 * @param orig �ndice do v�rtice de origem.
 * @param dest �ndice do v�rtice de destino.
 * @return int Retorna 1 em caso de sucesso, 0 se houver falha na aloca��o de mem�ria.
 */


Grafo* carregarFicheiro(const char* nomeFicheiro);/**
 * @brief Carrega um grafo a partir de um ficheiro de texto.
 * 
 * Esta fun��o l� um ficheiro linha a linha, identificando caracteres diferentes de '.'
 * como v�rtices. Atribui a cada v�rtice uma posi��o (x, y) com base na posi��o no ficheiro.
 * Ap�s carregar todos os v�rtices, liga automaticamente todos os v�rtices com a mesma
 * frequ�ncia atrav�s de arestas bidirecionais.
 * 
 * @param nomeFicheiro Nome do ficheiro a ser lido.
 * @return Apontador para o grafo criado. Retorna NULL se o ficheiro n�o puder ser aberto.
 */


int DFT(Grafo* grafo, int start, int visitados[]);/**
 * @brief Executa uma procura em profundidade no grafo.
 * 
 * Percorre os v�rtices do grafo a partir de um v�rtice inicial, usando uma pilha.
 * Guarda os �ndices dos v�rtices visitados na ordem em que foram explorados.
 * 
 * @param grafo Apontador para o grafo.
 * @param inicio �ndice do v�rtice inicial para a procura.
 * @param visitados Array onde ser�o armazenados os �ndices dos v�rtices visitados.
 * @return int N�mero total de v�rtices visitados.
 */


int BFT(Grafo* grafo, int start, int visitados[]);/**
 * @brief Executa uma procura em largura no grafo.
 * 
 * Utiliza uma fila para percorrer os v�rtices do grafo a partir de um v�rtice inicial,
 * visitando todos os v�rtices acess�veis por n�veis. 
 * 
 * @param grafo Apontador para o grafo.
 * @param inicio �ndice do v�rtice inicial.
 * @param visitados Array onde ser�o armazenados os �ndices dos v�rtices visitados.
 * @return int N�mero total de v�rtices visitados.
 */


int limparVisitados(Grafo* g);/**
 * @brief Limpa o estado de visita dos v�rtices do grafo.
 * 
 * Esta fun��o percorre todos os v�rtices do grafo e define o campo
 * `visitado` como `false`, indicando que nenhum v�rtice foi visitado.
 * 
 * @param g Apontador para a estrutura do grafo.
 * 
 * @return int Retorna 1 se o grafo for v�lido e os estados foram limpos,
 *             ou 0 se o apontador do grafo for NULL.
 */


int limparGrafo(Grafo* grafo);/**
 * @brief Liberta a mem�ria alocada para o grafo e as suas arestas.
 * 
 * Esta fun��o percorre todos os v�rtices do grafo, libertando a mem�ria
 * das listas de Arestas. Depois liberta a mem�ria dos v�rtices
 * e, por fim, do pr�prio grafo.
 * 
 * @param grafo Apontador para a estrutura do grafo.
 * 
 * @return int Retorna 1 se a liberta��o for bem-sucedida,
 *             ou 0 se o apontador do grafo for NULL.
 */

int encontrarCaminhos(Grafo* g, int atual, int destino, int* caminho, int pos);/**
 * @brief Encontra e imprime todos os caminhos poss�veis entre dois v�rtices num grafo.
 *
 * Esta fun��o realiza uma procura em profundidade (DFT) para encontrar todos os caminhos
 * do v�rtice 'atual' at� ao v�rtice 'destino'. Utiliza recurs�o para explorar os v�rtices adjacentes
 * que ainda n�o foram visitados. Cada caminho encontrado � impresso no formato (x, y) -> (x, y) -> ... .
 *
 * @param g Apontador para o grafo onde se realiza a procura.
 * @param atual �ndice do v�rtice atual onde a procura est� a acontecer.
 * @param destino �ndice do v�rtice destino que se pretende alcan�ar.
 * @param caminho Array que armazena os �ndices dos v�rtices que formam o caminho atual.
 * @param pos Posi��o atual no array 'caminho', indicando quantos v�rtices j� foram adicionados.
 * 
 * @return Retorna 1 se foi encontrado pelo menos um caminho, caso contr�rio 0.
 */


int listarIntersecoes(Grafo* g, int v1, int v2);/**
 * @brief Lista os v�rtices de um grafo que est�o alinhados com dois v�rtices dados.
 *
 * Esta fun��o percorre todos os v�rtices do grafo 
 * e identifica aqueles que est�o alinhados com ambos os v�rtices dados (`v1` e `v2`),
 * seja na mesma linha, mesma coluna ou na mesma diagonal~.
 * Os v�rtices encontrados s�o apresentados no ecr�
 * e o n�mero total de interse��es � devolvido.
 *
 * @param g Apontador para o grafo que cont�m os v�rtices.
 * @param v1 �ndice do primeiro v�rtice de refer�ncia.
 * @param v2 �ndice do segundo v�rtice de refer�ncia.
 * @return N�mero de v�rtices que est�o alinhados com os v�rtices v1 e v2.
 */


int guardarGrafoBinario(Grafo* grafo, const char* nomeArquivo);/**
 * @brief Guarda a estrutura do grafo num ficheiro bin�rio.
 * 
 * Esta fun��o escreve no ficheiro o n�mero de v�rtices, os dados de cada v�rtice
 *  e as listas de arestas de cada v�rtice.
 * 
 * @param grafo Apontador para a estrutura do grafo a guardar.
 * @param nomeArquivo Nome do ficheiro onde o grafo ser� guardado.
 * 
 * @return int Retorna 1 se o guardamento foi bem-sucedido, ou 0 em caso de erro.
 */


Grafo* carregarGrafoBinario(const char* nomeFicheiro);/**
 * @brief Carrega um grafo a partir de um ficheiro bin�rio.
 * 
 * Esta fun��o l� do ficheiro o n�mero de v�rtices, os dados de cada v�rtice
 * e reconstr�i as listas de adjac�ncia para cada v�rtice.
 * 
 * @param nomeFicheiro Nome do ficheiro bin�rio de onde o grafo ser� carregado.
 * 
 * @return Grafo* Apontador para o grafo carregado em mem�ria,
 *                ou NULL em caso de erro.
 */

#endif 
