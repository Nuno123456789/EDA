/*****************************************************************//**
 * \file   Dados.h
 * \brief  
 * 
 * \author Nuno Macedo
 * \date   May 2025
 *********************************************************************/

#ifndef DADOS_H
#define DADOS_H
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define MAX 100
typedef struct Aresta {
    int destino;
    struct Aresta* prox;
} Aresta;

typedef struct Vertice {
    char frequencia;
    int x;
    int y;
    Aresta* adj;
    bool visitado;
} Vertice;

typedef struct Grafo {
    Vertice* vertices;
    int numVertices;
} Grafo;

#endif
