/*******************************************************************
 * \file   Funcoes.h
 * \brief  
 * 
 * \author Nuno Macedo
 * \date   Mar�o 2025
 *********************************************************************/
#pragma once
#include "dados.h"

/**
 * @brief Fun��o para adicionar uma antena � lista ligada de forma ordenada por y e x.
 *
 * Esta fun��o adiciona uma nova antena � lista ligada, mantendo a lista ordenada
 * por coordenadas. Se j� existir uma antena nas mesmas coordenadas,
 * n�o � inserida a antena.
 *
 * @param inicio Apontador para o in�cio da lista de antenas.
 * @param frequencia A frequ�ncia da antena a ser adicionada.
 * @param x A coordenada x da antena a ser adicionada.
 * @param y A coordenada y da antena a ser adicionada.
 * @param status Apontador para vari�vel de status:
 *        - 1: Antena adicionada com sucesso.
 *        - 2: Antena j� existe nas mesmas coordenadas.
 *
 * @return Apontador para o in�cio da lista de antenas (pode ser alterado se a nova antena
 *         for inserida antes da primeira da lista).
 */Antena* adicionar_antena(Antena* inicio, char frequencia, int x, int y, int* status);


/**
 * @brief Fun��o para criar uma nova antena.
 *
 * Esta fun��o aloca mem�ria para uma nova antena, inicializa os seus valores
 * e devolve um apontador para a nova antena.
 *
 * @param frequencia A frequ�ncia da antena.
 * @param x A coordenada x da antena.
 * @param y A coordenada y da antena.
 *
 * @return Um apontador para a nova antena criada.
 */Antena* criar_antena(char frequencia, int x, int y);


/**
 * @brief Lista as antenas presentes na lista ligada.
 *
 * Esta fun��o percorre a lista ligada de antenas e imprime a frequ�ncia
 * e as coordenadas de cada uma. Caso a lista esteja vazia, informa que
 * n�o h� antenas para mostrar.
 *
 * @param h Apontador para o in�cio da lista de antenas.
 *
 * @return 1 se a lista contiver antenas, ou 0 se a lista estiver vazia.
 */int MostraLista(Antena* h);


/**
 * @brief Remove uma antena da lista ligada de acordo com as coordenadas escolhidas.
 *
 * Esta fun��o procura uma antena com as coordenadas escolhidas pelo utilizador
 * e remove-a da lista ligada, libertando a mem�ria correspondente.
 *
 * @param inicio Apontador para o in�cio da lista de antenas.
 * @param x Coordenada x da antena a ser removida.
 * @param y Coordenada y da antena a ser removida.
 * @param status Apontador para uma vari�vel que indica o estado da remo��o:
 *        - 1: Antena n�o encontrada.
 *        - 2: Antena removida com sucesso.
 *        - 3: Lista vazia.
 *
 * @return Retorna o in�cio da lista ligada atualizada. Se a antena removida era a primeira,
 *         o in�cio � alterado. Caso a lista esteja vazia ou a antena n�o seja encontrada,
 *         a fun��o retorna o apontador original.
 */Antena* RemoverAntena(Antena* inicio, int x, int y, int* status);


/**
 * @brief Cria um novo efeito nefasto com a frequ�ncia e coordenadas especificadas.
 *
 * A fun��o aloca mem�ria para um novo efeito nefasto e inicializa os seus dados,
 * incluindo a frequ�ncia e as coordenadas (x, y). 
 *
 * @param frequencia A frequ�ncia associada ao efeito nefasto.
 * @param x Coordenada x do efeito nefasto.
 * @param y Coordenada y do efeito nefasto.
 *
 * @return Retorna um apontador para o novo efeito nefasto criado.
 * 
 */EfeitoNefasto* criar_Nefasto(int x, int y);


/**
  * @brief Adiciona um novo efeito nefasto a uma lista ligada de forma ordenada.
  *
  * Esta fun��o adiciona um novo efeito nefasto � lista ligada. O efeito nefasto � inserido
  * de forma ordenada com base nas coordenadas (ordem: primeiro y, depois x).
  * Se j� existir um efeito nefasto nas mesmas coordenadas, o novo n�o ser� adicionado.
  *
  * @param inicio Apontador para o in�cio da lista de efeitos nefastos.
  * @param x Coordenada x do novo efeito nefasto.
  * @param y Coordenada y do novo efeito nefasto.
  *
  * @return Retorna o in�cio da lista de efeitos nefastos atualizada.
  */EfeitoNefasto* adicionar_efeito_nefasto(EfeitoNefasto* inicio, int x, int y);


/**
   * @brief Verifica e adiciona efeitos nefastos entre antenas com a mesma frequ�ncia.
   *
   * Percorre a lista de antenas e identifica pares de antenas com a mesma frequ�ncia
   * que est�o a uma dist�ncia horizontal ou vertical de at� 2 unidades. Se tal situa��o
   * for encontrada, um efeito nefasto � gerado no ponto m�dio entre as duas antenas
   * e adicionado � lista de efeitos nefastos.
   *
   * @param inicio Apontador para o in�cio da lista de antenas.
   * @param listaEfeitos Apontador para o in�cio da lista de efeitos nefastos.
   *
   * @return Retorna a lista de efeitos nefastos atualizada.
   */EfeitoNefasto* verificar_efeito_nefasto(Antena* inicio, EfeitoNefasto* listaEfeitos);


/**
	* @brief Lista todos os efeitos nefastos armazenados na lista ligada.
	*
	* A fun��o percorre a lista de efeitos nefastos e imprime as suas coordenadas.
	* Caso a lista esteja vazia, uma mensagem � exibida avisando.
	*
	* @param h Apontador para o in�cio da lista de efeitos nefastos.
	*
	* @return Retorna 0 se a lista estiver vazia, e 1 se listar com sucesso.
	*/int listar_efeitos_nefastos(EfeitoNefasto* h);


/**
* @brief Carrega as antenas a partir de um ficheiro de texto.
*
 * Esta fun��o l� os dados de um ficheiro de texto onde cada linha cont�m os dados de uma antena,
 * incluindo a frequ�ncia e as coordenadas (x, y). A fun��o adiciona as antenas � lista ligada de antenas.
 * 
 * @param filename Nome do ficheiro de onde os dados das antenas ser�o lidos.
 * @param ListAnt Ponteiro para a lista ligada de antenas onde as novas antenas ser�o adicionadas.
 *
 * @return Retorna a lista ligada de antenas atualizada com os dados lidos do ficheiro.
 *
 */Antena* carregar_mapa(const char* filename, Antena* ListAnt);


/**
   * @brief Guarda as antenas num ficheiro de texto.
   *
   * Esta fun��o percorre a lista de antenas e grava os dados de cada antena (frequ�ncia,
   * coordenadas x e y) num ficheiro de texto especificado. 
   *
   * @param filename Nome do ficheiro onde os dados das antenas ser�o guardados.
   * @param ListAnt Ponteiro para a lista ligada de antenas a serem guardadas.
   *
   * @return Retorna 1 se o ficheiro foi gravado com sucesso, ou 0 em caso de erro.
   *
   */int guardar_mapa(const char* filename, Antena* ListAnt);

