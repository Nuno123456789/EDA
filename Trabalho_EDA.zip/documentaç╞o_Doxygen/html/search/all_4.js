var searchData=
[
  ['efeitonefasto_0',['EfeitoNefasto',['../_dados_8h.html#a01db73ee9626787b63e0313881713dfd',1,'Dados.h']]],
  ['efeitonefasto_1',['efeitoNefasto',['../structefeito_nefasto.html',1,'']]]
];
