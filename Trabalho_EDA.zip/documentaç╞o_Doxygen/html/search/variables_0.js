var searchData=
[
  ['frequencia_0',['frequencia',['../structantena.html#aee34bf561e09b1bbe9bc27932b16132a',1,'antena']]]
];
