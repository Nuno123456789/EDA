var searchData=
[
  ['carregar_5fmapa_0',['carregar_mapa',['../_funcoes_8c.html#a6e3228536bf52f275a45cfaefa20b340',1,'carregar_mapa(const char *filename, Antena *ListAnt):&#160;Funcoes.c'],['../_funcoes_8h.html#a6e3228536bf52f275a45cfaefa20b340',1,'carregar_mapa(const char *filename, Antena *ListAnt):&#160;Funcoes.c']]],
  ['criar_5fantena_1',['criar_antena',['../_funcoes_8c.html#a41f62281701d354c6657bcc9e1c0e570',1,'criar_antena(char frequencia, int x, int y):&#160;Funcoes.c'],['../_funcoes_8h.html#a41f62281701d354c6657bcc9e1c0e570',1,'criar_antena(char frequencia, int x, int y):&#160;Funcoes.c']]],
  ['criar_5fnefasto_2',['criar_Nefasto',['../_funcoes_8c.html#a34f982bca780f3add64947bd17079e1d',1,'criar_Nefasto(int x, int y):&#160;Funcoes.c'],['../_funcoes_8h.html#a34f982bca780f3add64947bd17079e1d',1,'criar_Nefasto(int x, int y):&#160;Funcoes.c']]]
];
