var searchData=
[
  ['listar_5fefeitos_5fnefastos_0',['listar_efeitos_nefastos',['../_funcoes_8c.html#a7158462afa6a80876e949700cf557097',1,'listar_efeitos_nefastos(EfeitoNefasto *h):&#160;Funcoes.c'],['../_funcoes_8h.html#a7158462afa6a80876e949700cf557097',1,'listar_efeitos_nefastos(EfeitoNefasto *h):&#160;Funcoes.c']]]
];
