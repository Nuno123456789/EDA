/*******************************************************************
 * \file   Dados.h
 * \brief  
 * 
 * \author Nuno Macedo
 * \date   Mar�o 2025
 *********************************************************************/
#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

// Estrutura de uma antena
typedef struct antena {
    char frequencia;
    int x, y;
    struct antena* prox;
} Antena;

typedef struct efeitoNefasto {
    int x, y;
    struct efeitoNefasto* prox;
} EfeitoNefasto;
