/*******************************************************************
 * \file   Funcoes.c
 * \brief  
 * 
 * \author Nuno Macedo
 * \date   Mar�o 2025
 *********************************************************************/
#define _CRT_SECURE_NO_WARNINGS

#include "dados.h"
#include "funcoes.h"


#pragma region Criar Antenas


// Fun��o para criar uma nova antena
Antena* criar_antena(char frequencia, int x, int y) {

    //cria um espa�o na memoria para guardar os dados da antena
    Antena* nova_antena = (Antena*)malloc(sizeof(Antena));
    nova_antena->frequencia = frequencia;
    nova_antena->x = x;
    nova_antena->y = y;
    nova_antena->prox = NULL;
    return nova_antena;

}



// Fun��o para adicionar uma antena � lista ligada de forma ordenada por y e x 
Antena* adicionar_antena(Antena* inicio, char frequencia, int x, int y, int* status) {

    // Verifica se j� existe uma antena nas mesmas coordenadas
    Antena* temp = inicio;
    while (temp != NULL) {
        if (temp->x == x && temp->y == y) {
            *status = 2;  // Antena j� existe nas mesmas coordenadas
            return inicio;
        }
        temp = temp->prox;
    }

    // Cria a nova antena
    Antena* nova_antena = criar_antena(frequencia, x, y);

    // Se a lista estiver vazia, a nova antena ser� o primeiro elemento
    if (inicio == NULL) {
        *status = 1;  // Inserido com sucesso
        return nova_antena;
    }

    // Se a nova antena deve ser inserida antes do primeiro elemento (ordem por y, depois x)
    if (y < inicio->y || (y == inicio->y && x < inicio->x)) {
        nova_antena->prox = inicio;
        *status = 1;  // Inserido com sucesso
        return nova_antena;
    }

    // Caso contr�rio, percorre a lista para encontrar o local correto
    temp = inicio;
    while (temp->prox != NULL &&
        (temp->prox->y < y || (temp->prox->y == y && temp->prox->x < x))) {
        temp = temp->prox;
    }

    // Insere a nova antena
    nova_antena->prox = temp->prox;
    temp->prox = nova_antena;
    *status = 1;  // Inserido com sucesso

    return inicio;
}

#pragma endregion


#pragma region Mostrar Antenas

//Lista as Antenas
int MostraLista(Antena* h) {
    Antena* aux = h;
    if (!h) {
        printf("Lista vazia!\n");
        return 0;
    }
    while (aux != NULL) {
        printf("Frequencia: %c, Coordenadas: (%d, %d)\n", aux->frequencia, aux->x, aux->y);
        aux = aux->prox;
    }
    return 1;
}
#pragma endregion


#pragma region Remover Antenas

Antena* RemoverAntena(Antena* inicio, int x, int y, int* status) {
    
    if (inicio == NULL) {
        *status = 3;      
        return NULL;
    }

    // Se a antena a ser removida estiver na primeira posi��o
    if (inicio->x == x && inicio->y == y) {
        Antena* temp = inicio;
        inicio = inicio->prox;  // Atualiza o in�cio da lista
        free(temp); 
        *status = 2;       
        return inicio;  // Retorna o novo in�cio da lista
    }

    // Percorre a lista para procurar a antena
    Antena* atual = inicio;
    while (atual->prox != NULL) {
        if ( atual->prox->x == x && atual->prox->y == y) {
            Antena* temp = atual->prox;
            atual->prox = atual->prox->prox;  // Ajusta o apontador para remover a antena sem perder o resto da lista
            free(temp);  // Liberta a mem�ria
            *status = 2;
            return inicio;  // Retorna a lista atualizada
        }
        atual = atual->prox;
    }

    *status = 1;
    return inicio;  // Retorna a lista sem altera��es

}

#pragma endregion



#pragma region Validar Efeito Nefasto

//Validar posi��es com efeito nefasto
EfeitoNefasto* verificar_efeito_nefasto(Antena* inicio, EfeitoNefasto* listaEfeitos) {
    Antena* temp1 = inicio;
    Antena* temp2;

    // Percorre todas as antenas
    while (temp1 != NULL) {
        temp2 = temp1->prox;
        while (temp2 != NULL) {
            // Verifica se as antenas t�m a mesma frequ�ncia
            if (temp1->frequencia == temp2->frequencia) {
                // Valida a dist�ncia  na horizontal ou vertical
                if ((temp1->x == temp2->x && abs(temp1->y - temp2->y) <= 2) ||
                    (temp1->y == temp2->y && abs(temp1->x - temp2->x) <= 2)) {
                    // Calcula para o local do efeito nefasto
                    int efeito_x = (temp1->x + temp2->x) / 2;
                    int efeito_y = (temp1->y + temp2->y) / 2;

                    // Adiciona o efeito nefasto � lista
                    listaEfeitos = adicionar_efeito_nefasto(listaEfeitos, efeito_x, efeito_y);
                }
            }
            temp2 = temp2->prox;
        }
        temp1 = temp1->prox;
    }

    return listaEfeitos;
}

#pragma endregion


#pragma region Listar Efeitos Nefastos

int listar_efeitos_nefastos(EfeitoNefasto* h) {
    EfeitoNefasto* aux = h;
    if (!h) {
        printf("Nenhum efeito nefasto encontrado.\n");
        return;
    }

    while (aux != NULL) {
        printf(" Local do efeito nefasto: (%d, %d)\n", aux->x, aux->y);
        aux = aux->prox;
    }
}

#pragma endregion



#pragma region Criar Efeito Nefasto
EfeitoNefasto* criar_Nefasto( int x, int y) {

    //cria um espa�o na memoria para guardar os dados da antena
    EfeitoNefasto* novoEfeito = (EfeitoNefasto*)malloc(sizeof(EfeitoNefasto));
    novoEfeito->x = x;
    novoEfeito->y = y;
    novoEfeito->prox = NULL;
    return novoEfeito;

}

EfeitoNefasto* adicionar_efeito_nefasto(EfeitoNefasto* inicio, int x, int y) {
    // Cria o novo efeito nefasto
    EfeitoNefasto* novoNefasto = criar_Nefasto( x, y);

    // Verifica se o efeito nefasto j� existe na lista
    EfeitoNefasto* temp = inicio;
    while (temp != NULL) {
        if (temp->x == x && temp->y == y) {
            free(novoNefasto);  // Libera a mem�ria do novo efeito caso ja exista
            return inicio;
        }
        temp = temp->prox;
    }

    // Se a lista estiver vazia, o novo efeito ser� o primeiro elemento
    if (inicio == NULL) {
        return novoNefasto;
    }

    // Se o novo efeito deve ser inserido antes do primeiro elemento (ordem por y, depois x)
    if (y < inicio->y || (y == inicio->y && x < inicio->x)) {
        novoNefasto->prox = inicio;
        return novoNefasto;
    }

    // Caso contr�rio, percorre a lista para encontrar o local correto de inser��o
    temp = inicio;
    while (temp->prox != NULL && (temp->prox->y < y || (temp->prox->y == y && temp->prox->x < x))) {
        temp = temp->prox;
    }

    // Insere o novo efeito na posi��o correta
    novoNefasto->prox = temp->prox;
    temp->prox = novoNefasto;

    return inicio;
}

#pragma endregion



#pragma region CarregarTXT

// Fun��o para carregar as antenas a partir de um ficheiro de texto
Antena* carregar_mapa(const char* filename, Antena* ListAnt) {
    int status = 0;
    FILE* arquivo = fopen(filename, "r");  // Abre o ficheiro para leitura
    if (arquivo == NULL) {
        return NULL;  // Retorna NULL em caso de erro
    }

    char frequencia;
    int x, y;

    // L� as antenas linha por linha
    while (fscanf(arquivo, " %c %d %d", &frequencia, &x, &y) == 3) {
        // Adiciona a antena na lista
        ListAnt = adicionar_antena(ListAnt, frequencia, x, y, &status);
    }

    fclose(arquivo);  // Fecha o ficheiro
    return ListAnt;  // Retorna a lista ligada de antenas
}


#pragma endregion



#pragma region GuardarTXT

// Fun��o para guardar as antenas num ficheiro de texto
int guardar_mapa(const char* filename, Antena* ListAnt) {
    FILE* arquivo = fopen(filename, "w");  // Abre o ficheiro para escrita
    if (arquivo == NULL) {
        return 0;  // Retorna 0 em caso de erro
    }

    Antena* temp = ListAnt;

    // Percorre a lista de antenas e escreve no ficheiro
    while (temp != NULL) {
        fprintf(arquivo, "%c %d %d\n", temp->frequencia, temp->x, temp->y);
        temp = temp->prox;
    }

    fclose(arquivo);  // Fecha o ficheiro
    return 1;  // Retorna 1 em caso de sucesso
}

#pragma endregion 
