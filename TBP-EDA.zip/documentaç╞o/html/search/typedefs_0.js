var searchData=
[
  ['antena_0',['Antena',['../_dados_8h.html#a3b33a83b140928878dd5d32af4cb8c43',1,'Dados.h']]]
];
