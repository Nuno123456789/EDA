var searchData=
[
  ['frequencia_0',['frequencia',['../structantena.html#aee34bf561e09b1bbe9bc27932b16132a',1,'antena']]],
  ['funcoes_2ec_1',['Funcoes.c',['../_funcoes_8c.html',1,'']]],
  ['funcoes_2eh_2',['Funcoes.h',['../_funcoes_8h.html',1,'']]]
];
