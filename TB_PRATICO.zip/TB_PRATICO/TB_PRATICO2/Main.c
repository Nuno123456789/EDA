/*******************************************************************
 * \file   Main.c
 * \brief  
 * 
 * \author Nuno Macedo
 * \date   Mar�o 2025
 *********************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include "funcoes.h"
#include "dados.h"



int main() {
    Antena* Lista = NULL; // Lista de antenas
    EfeitoNefasto* listaNefastos = NULL;  // Lista de efeitos nefastos

    char freq;
    int x, y, r;
    int largura, altura, status;
    char opcao;

    do {
        printf("\n1 - Carregar Mapa de Antenas\n");
        printf("2 - Inserir Antena\n");
        printf("3 - Consultar Lista de Antenas\n");
        printf("4 - Remover Antena\n");
        printf("5 - Ver Efeito Nefasto\n");
        printf("6 - Guardar alteracoes\n");
        printf("S - Sair\n");
        printf("Insira a opcao: ");
        scanf(" %c", &opcao);

        switch (opcao) {
        case '1':
            // Carregar o mapa de antenas de um arquivo
            Lista = carregar_mapa("mapa.txt", Lista);
            if (Lista == NULL) {  
                printf("\nErro ao abrir o arquivo ou carregar o mapa.\n");
            }
            else {
                printf("\nMapa carregado com sucesso!\n");
            }
            break;

        case '2':
            // Inserir novas antenas
            printf("Insira a frequencia da antena: ");
            scanf(" %c", &freq);
            printf("Insira a coordenada X da antena: ");
            scanf("%d", &x);
            printf("Insira a coordenada Y da antena: ");
            scanf("%d", &y);
            Lista = adicionar_antena(Lista, freq, x, y, &status);

            if (status == 2) {
                printf("\nErro: Ja existe uma antena na posicao (%d, %d)!\n", x, y);
            }
            else {
                printf("\nAntena adicionada com sucesso!\n");
            }
            break;

        case '3':
            //Listar Lista de Antenas
            printf("Lista de Antenas:\n\n");
            r = MostraLista(Lista);

            break;

        case '4':
            // Eliminar antenas
            printf("Insira a coordenada X da antena: ");
            scanf("%d", &x);
            printf("Insira a coordenada Y da antena: ");
            scanf("%d", &y);

            RemoverAntena(Lista, x, y, &status);

            if (status == 2) {
                printf("\nAntena %c removida em (%d, %d)\n",  x, y);
            }
            else if (status == 1 ) {
                printf("\nAntena %c n�o encontrada em (%d, %d)\n",  x, y);
               
            }
            else {
                printf("\nLista vazia, nenhuma antena para remover.\n");
            }

            break;

        case '5':
            // Validar o efeito nefasto
            listaNefastos = verificar_efeito_nefasto(Lista, listaNefastos);
            // Listar os efeitos armazenados
            printf("\nEfeitos nefastos detectados:\n\n");
            r = listar_efeitos_nefastos(listaNefastos);

            break;

        case '6':
            guardar_mapa("mapa.txt", Lista);
            if (Lista == NULL) {
                printf("\nErro ao guardar os dados no mapa.\n");
            }
            else {
                printf("\nMapa guardado com sucesso!\n");
            }
            break;

        default:
            break;
        }
    } while (opcao != 'S' && opcao != 's');

    return 0;
}
