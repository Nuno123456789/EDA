var searchData=
[
  ['x_0',['x',['../structantena.html#afb2aea0bd79533101e6cb97a7f91ce3c',1,'antena::x'],['../structefeito_nefasto.html#a4abd7e5ef8f8704f6c0e24bac97d2f3a',1,'efeitoNefasto::x']]]
];
