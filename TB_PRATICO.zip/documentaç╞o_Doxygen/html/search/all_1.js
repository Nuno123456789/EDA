var searchData=
[
  ['adicionar_5fantena_0',['adicionar_antena',['../_funcoes_8c.html#ad864f82e3ef3ac7f0ad4a56a691ac14c',1,'adicionar_antena(Antena *inicio, char frequencia, int x, int y, int *status):&#160;Funcoes.c'],['../_funcoes_8h.html#ad864f82e3ef3ac7f0ad4a56a691ac14c',1,'adicionar_antena(Antena *inicio, char frequencia, int x, int y, int *status):&#160;Funcoes.c']]],
  ['adicionar_5fefeito_5fnefasto_1',['adicionar_efeito_nefasto',['../_funcoes_8c.html#a88150ca771083212c82045e6c9ae9edf',1,'adicionar_efeito_nefasto(EfeitoNefasto *inicio, int x, int y):&#160;Funcoes.c'],['../_funcoes_8h.html#a88150ca771083212c82045e6c9ae9edf',1,'adicionar_efeito_nefasto(EfeitoNefasto *inicio, int x, int y):&#160;Funcoes.c']]],
  ['antena_2',['Antena',['../_dados_8h.html#a3b33a83b140928878dd5d32af4cb8c43',1,'Dados.h']]],
  ['antena_3',['antena',['../structantena.html',1,'']]]
];
