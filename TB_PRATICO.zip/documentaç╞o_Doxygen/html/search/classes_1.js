var searchData=
[
  ['efeitonefasto_0',['efeitoNefasto',['../structefeito_nefasto.html',1,'']]]
];
