var searchData=
[
  ['y_0',['y',['../structantena.html#ad809df819fbcb6716ad1e395e11bd856',1,'antena::y'],['../structefeito_nefasto.html#a57c884847c1160558cf35ec96f20e889',1,'efeitoNefasto::y']]]
];
