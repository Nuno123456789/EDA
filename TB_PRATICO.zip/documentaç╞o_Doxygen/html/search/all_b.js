var searchData=
[
  ['verificar_5fefeito_5fnefasto_0',['verificar_efeito_nefasto',['../_funcoes_8c.html#a0ed79f17ab32275e0e59504dd736cf94',1,'verificar_efeito_nefasto(Antena *inicio, EfeitoNefasto *listaEfeitos):&#160;Funcoes.c'],['../_funcoes_8h.html#a0ed79f17ab32275e0e59504dd736cf94',1,'verificar_efeito_nefasto(Antena *inicio, EfeitoNefasto *listaEfeitos):&#160;Funcoes.c']]]
];
